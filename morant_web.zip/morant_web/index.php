<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home - Sierra Leone Organisation Platform</title>
    <style>
        body { font-family: Tahoma; font-size: 12px; text-align: center; padding: 50px; background: #fdfdfd; }
        .logo { display: block; width: 300px; max-width: 100%; height: auto; margin: 0 auto 20px; }
        .btn { display: inline-block; padding: 10px 22px; background: #e83e8c; color: white; text-decoration: none; border-radius: 4px; margin: 6px; font-weight: bold; }
        .btn:hover { background: #d63384; }
        footer { margin-top: 80px; font-family: Tahoma; font-size: 12px; color: #555; }
    </style>
</head>
<body>
    <!-- Logo Requirement: Django Girls Logo[cite: 1] -->
    <img src="django.jpg" alt="Django Girls Logo" class="logo">
    <h1>Sierra Leone Organisation Web Platform</h1>
    <p>Welcome to Morant's service-layer portal. Please select your action below:</p>
    
    <div style="margin: 20px 0;">
        <a href="signup.php" class="btn">Sign Up</a>
        <a href="login.php" class="btn">Login</a>
    </div>

    <!-- Mandatory Footer Requirement[cite: 2] -->
    <footer>Abdulrahim F Conteh, Information and Communications Technology, Semester 05, [Insert ID], 2026</footer>
</body>
</html>
