<?php
require_once 'Database.php';

class AuthService {
    private $conn;

    public function __construct() {
        $db = new Database();
        $this->conn = $db->connect();
    }

    public function registerUser($name, $email, $password) {
        // Security: Password Hashing implementation
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $this->conn->prepare("INSERT INTO enterprise_users (full_name, email_address, secure_password) VALUES (?, ?, ?)");
        return $stmt->execute([$name, $email, $hashed_password]);
    }

    public function loginUser($email, $password) {
        $stmt = $this->conn->prepare("SELECT * FROM enterprise_users WHERE email_address = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['secure_password'])) {
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['full_name'] = $user['full_name'];
            return true;
        }
        return false;
    }
}
?>
