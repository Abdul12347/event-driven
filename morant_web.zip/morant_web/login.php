<?php
require_once 'AuthService.php';
$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $auth = new AuthService();
    if ($auth->loginUser($_POST['email'], $_POST['password'])) {
        header("Location: dashboard.php");
        exit();
    } else {
        $error_message = "Invalid email address or password combination.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Login</title>
    <style>
        body { font-family: Tahoma; font-size: 12px; padding: 40px; text-align: center; }
        .logo { display: block; width: 300px; max-width: 100%; height: auto; margin: 0 auto 20px; }
        .box { display: inline-block; text-align: left; background: #ffffff; padding: 25px; border: 1px solid #ccc; border-radius: 5px; }
        input { width: 260px; padding: 8px; margin: 5px 0 15px 0; border: 1px solid #ccc; border-radius: 3px; font-family: Tahoma; font-size: 12px; }
        button { background: #28a745; color: white; border: none; padding: 9px 15px; border-radius: 3px; cursor: pointer; font-family: Tahoma; font-size: 12px; font-weight: bold; }
        footer { margin-top: 50px; font-family: Tahoma; font-size: 12px; }
    </style>
</head>
<body>
    <img src="django.jpg" alt="Django Girls Logo" class="logo">
    <h2>Secure System Login</h2>
    <p style="color: red;"><?php echo $error_message; ?></p>
    
    <div class="box">
        <form method="POST">
            <label>Email Address:</label><br>
            <input type="email" name="email" required><br>
            <label>Password:</label><br>
            <input type="password" name="password" required><br>
            <button type="submit">Login to Portal</button>
        </form>
    </div>
    <p style="margin-top: 15px;"><a href="index.php">Home</a> | <a href="signup.php">Sign Up</a></p>

    <footer>Abdulrahim F Conteh, Information and Communications Technology, Semester 05, [Insert ID], 2026</footer>
</body>
</html>
