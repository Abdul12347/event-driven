<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <style>
        body { font-family: Tahoma; font-size: 12px; padding: 50px; text-align: center; }
        .logo { display: block; width: 300px; max-width: 100%; height: auto; margin: 0 auto 20px; }
        .panel { display: inline-block; background: #f8f9fa; border: 1px solid #dee2e6; padding: 30px; border-radius: 6px; width: 450px; }
        .logout-btn { color: #dc3545; font-weight: bold; text-decoration: none; border: 1px solid #dc3545; padding: 8px 16px; border-radius: 4px; display: inline-block; margin-top: 15px; }
        .logout-btn:hover { background: #dc3545; color: white; }
        footer { margin-top: 80px; font-family: Tahoma; font-size: 12px; }
    </style>
</head>
<body>
    <img src="django.jpg" alt="Django Girls Logo" class="logo">
    
    <div class="panel">
        <h1>Welcome, <?php echo htmlspecialchars($_SESSION['full_name']); ?>!</h1>
        <p>You have successfully accessed your secure member dashboard[cite: 1].</p>
        <p>Your authentication session is active and monitored.</p>
        <br>
        <a href="logout.php" class="logout-btn">Terminate Session (Logout)</a>
    </div>

    <footer>Abdulrahim F Conteh, Information and Communications Technology, Semester 05, [Insert ID], 2026</footer>
</body>
</html>
