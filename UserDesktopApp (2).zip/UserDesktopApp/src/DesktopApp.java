import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

public class DesktopApp extends JFrame {

    private final JLabel mainTitle;
    private final JButton textActionBtn;
    private final JButton bgActionBtn;
    private final JPanel basePanel;

    public DesktopApp() {
        super("Java Swing Assignment");
        this.setSize(new Dimension(800, 800));
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null);

        // Icon Setup
        setWindowLogo("assets/app_logo.png");

        // Primary Panel Configuration
        basePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 30));
        basePanel.setBackground(new Color(238, 238, 238));

        // Title Label Setup
        mainTitle = new JLabel("Welcome to Java Swing First Individual Assignment by Coach Makka");
        mainTitle.setFont(new Font("Verdana", Font.BOLD, 16));
        mainTitle.setForeground(new Color(25, 25, 25));

        // Instantiate Controls
        textActionBtn = new JButton("Change Text");
        bgActionBtn = new JButton("Change Background");

        textActionBtn.setFocusable(false);
        bgActionBtn.setFocusable(false);

        // Event Handling with Inner Handler Classes
        textActionBtn.addActionListener(new TextChangeHandler());
        bgActionBtn.addActionListener(new BackgroundChangeHandler());

        // Secondary Panel for Button Alignment
        JPanel btnGroup = new JPanel(new FlowLayout(FlowLayout.CENTER, 18, 0));
        btnGroup.setOpaque(false);
        btnGroup.add(textActionBtn);
        btnGroup.add(bgActionBtn);

        // Add to Base Container
        basePanel.add(mainTitle);
        basePanel.add(btnGroup);
        this.add(basePanel);
    }

    private void setWindowLogo(String path) {
        try {
            ImageIcon logo = new ImageIcon(path);
            this.setIconImage(logo.getImage());
        } catch (Exception ex) {
            System.out.println("Default icon used.");
        }
    }

    // Explicit Inner Event Listener Classes
    private class TextChangeHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            mainTitle.setText("Text updated! Event Driven Programming in Java Swing.");
        }
    }

    private class BackgroundChangeHandler implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            basePanel.setBackground(new Color(217, 130, 43)); // Soft Mint Green
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            DesktopApp app = new DesktopApp();
            app.setVisible(true);
        });
    }
}